--Kelompok 4 Database Systems LI01
--NIM - Nama
--1. 2440106030 - Brian Steve
--2. 2440092151 - Daniel widjaja
--3. 2440079446 - Alexander
--4. 2440105173 - Tania Lipiena
--5. 2440104391 - Ayunda Raaziqi
--6. 2440104271 - Jeanie
--7.2440091344 - Dyandra Maheswari
--8. 2440105942 - Dewi Sri Rejeki

USE Supermarket

INSERT INTO MsCategory VALUES
('CT001', 'Snacks'),
('CT002', 'Beverages'),
('CT003', 'Houseware'),
('CT004', 'Cigarettes'),
('CT005', 'Instant Food'),
('CT006', 'Beauty'),
('CT007', 'Baby & Kids'),
('CT008', 'Health & Personal Care'),
('CT009', 'Fruits'),
('CT010', 'Vegetables')

INSERT INTO MsProduct VALUES
('PD001', 'CT001', 'Chitota Barbeque', 10000, 65),
('PD002', 'CT001', 'Yipu Gummy Bears', 3000, 50),
('PD003', 'CT002', 'Aquo', 5000, 100),
('PD004', 'CT003', 'Moonlight', 12000, 40),
('PD005', 'CT004', 'Gudang Gula', 20000, 25),
('PD006', 'CT005', 'Indomi', 2500, 130),
('PD007', 'CT006', 'Emino', 30000, 50),
('PD008', 'CT007', 'MyBaby', 25000, 35),
('PD009', 'CT009', 'Pisang Sunset', 10000, 10),
('PD010', 'CT010', 'Wortel', 5000, 15),
('PD011', 'CT008', 'Dottel', 15000, 5)

INSERT INTO MsStaffPosition VALUES
('SP1', 'Manager'),
('SP2', 'Cashier'),
('SP3', 'OB'),
('SP4', 'Delivery')

INSERT INTO MsStaff VALUES
('ST001', 'SP1', 'Lily', 'Female', 'Lily97@gmail.com', '1997-05-02'),
('ST002', 'SP2', 'Alyssa', 'Female', 'Alyssa.m@gmail.com', '1999-12-01'),
('ST003', 'SP3', 'Tommy', 'Male', 'TommyL@yahoo.com', '1998-01-22'),
('ST004', 'SP2', 'Sara', 'Female', 'Sara11@yahoo.com', '2000-11-11'),
('ST005', 'SP4', 'David', 'Male', 'David.01@gmail.com', '1996-01-07')

INSERT INTO PaymentMethod VALUES
('PM1', 'Cash'),
('PM2', 'Credit'),
('PM3', 'Debit')

INSERT INTO TransactionHeader VALUES 
('TS001', 'ST002', '2020-07-06', 'PM1'),
('TS002', 'ST002', '2020-10-10', 'PM2'),
('TS003', 'ST002', '2020-12-03', 'PM2'),
('TS004', 'ST004', '2021-01-25', 'PM3'),
('TS005', 'ST004', '2021-05-18', 'PM1')

INSERT INTO TransactionDetail VALUES
('TS001', 'PD001', 7),
('TS001', 'PD004', 3),
('TS001', 'PD007', 2),
('TS002', 'PD002', 1),
('TS002', 'PD003', 5),
('TS002', 'PD005', 4),
('TS003', 'PD005', 2),
('TS003', 'PD007', 8),
('TS003', 'PD008', 2),
('TS003', 'PD010', 1),
('TS004', 'PD003', 9),
('TS005', 'PD002', 7),
('TS005', 'PD009', 4)