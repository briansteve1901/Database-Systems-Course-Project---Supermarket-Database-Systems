--Kelompok 4 Database Systems LI01
--NIM - Nama
--1. 2440106030 - Brian Steve
--2. 2440092151 - Daniel widjaja
--3. 2440079446 - Alexander
--4. 2440105173 - Tania Lipiena
--5. 2440104391 - Ayunda Raaziqi
--6. 2440104271 - Jeanie
--7.2440091344 - Dyandra Maheswari
--8. 2440105942 - Dewi Sri Rejeki

CREATE DATABASE Supermarket
GO
USE Supermarket

CREATE TABLE MsCategory(
	CategoryID CHAR(5) PRIMARY KEY CHECK(CategoryID LIKE 'CT[0-9][0-9][0-9]'), 
	CategoryName VARCHAR(255) NOT NULL
)

CREATE TABLE MsProduct(
	ProductID CHAR(5) PRIMARY KEY CHECK(ProductID LIKE 'PD[0-9][0-9][0-9]'),
	CategoryID CHAR(5) FOREIGN KEY REFERENCES MsCategory(CategoryID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	ProductName VARCHAR(255) NOT NULL,
	ProductPrice INT NOT NULL,
	Stock INT NOT NULL
)

CREATE TABLE MsStaffPosition(
	StaffPositionID CHAR(3) PRIMARY KEY CHECK(StaffPositionID LIKE 'SP[0-9]'),
	StaffPosition VARCHAR(255) NOT NULL
)

CREATE TABLE MsStaff(
	StaffID CHAR(5) PRIMARY KEY CHECK(StaffID LIKE 'ST[0-9][0-9][0-9]'),
	StaffPositionID CHAR(3) FOREIGN KEY REFERENCES MsStaffPosition(StaffPositionID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	StaffName VARCHAR(255) NOT NULL,
	StaffGender VARCHAR(8) CHECK(StaffGender IN ('Male','Female')),
	StaffEmail VARCHAR(255) check(StaffEmail LIKE '%@%'),
	StaffDOB DATE NOT NULL
)

CREATE TABLE PaymentMethod(
	PaymentMethodID CHAR(3) PRIMARY KEY CHECK(PaymentMethodID LIKE 'PM[0-9]'),
	PaymentMethodName VARCHAR(255) NOT NULL
)

CREATE TABLE TransactionHeader(
	TransactionID CHAR(5) PRIMARY KEY CHECK(TransactionID LIKE 'TS[0-9][0-9][0-9]'),
	StaffID CHAR(5) FOREIGN KEY REFERENCES MsStaff(StaffID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	TransactionDate DATE NOT NULL,
	PaymentMethodID CHAR(3) FOREIGN KEY REFERENCES PaymentMethod(PaymentMethodID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL
)

CREATE TABLE TransactionDetail(
	TransactionID CHAR(5) FOREIGN KEY REFERENCES TransactionHeader(TransactionID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	ProductID CHAR(5) FOREIGN KEY REFERENCES MsProduct(ProductID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	Quantity INT NOT NULL,
	PRIMARY KEY(TransactionID, ProductID)
)