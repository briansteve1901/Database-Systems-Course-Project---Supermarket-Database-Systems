--Kelompok 4 Database Systems LI01
--NIM - Nama
--1. 2440106030 - Brian Steve
--2. 2440092151 - Daniel widjaja
--3. 2440079446 - Alexander
--4. 2440105173 - Tania Lipiena
--5. 2440104391 - Ayunda Raaziqi
--6. 2440104271 - Jeanie
--7.2440091344 - Dyandra Maheswari
--8. 2440105942 - Dewi Sri Rejeki


USE Supermarket

GO
CREATE VIEW ViewStaffFemale AS
SELECT * 
FROM MsStaff
WHERE StaffGender = 'Female'
GO

GO
CREATE VIEW ViewTransaction2020Credit AS
SELECT TransactionID, StaffID, TransactionDate, PaymentMethodName
FROM TransactionHeader TH
JOIN PaymentMethod PM
ON TH.PaymentMethodID = PM.PaymentMethodID
WHERE YEAR(TH.TransactionDate) = '2020' AND PM.PaymentMethodName = 'Credit'
GO

GO
CREATE VIEW ViewSnacks AS
SELECT ProductID,ProductName, ProductPrice, Stock, CategoryName
FROM MsProduct MP
JOIN MsCategory MC
ON MP.CategoryID = MC.CategoryID
WHERE CategoryName = 'Snacks'
GO

